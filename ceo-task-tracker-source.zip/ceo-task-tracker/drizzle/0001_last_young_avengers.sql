CREATE TABLE `app_settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `branches` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `identities` (
	`email` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`owner` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_identities_user` ON `identities` (`user_id`);--> statement-breakpoint
CREATE TABLE `memberships` (
	`branch` text NOT NULL,
	`email` text NOT NULL,
	`role` text DEFAULT 'staff' NOT NULL,
	PRIMARY KEY(`branch`, `email`)
);
--> statement-breakpoint
CREATE INDEX `idx_memberships_email` ON `memberships` (`email`);--> statement-breakpoint
ALTER TABLE `employees` ADD `branch` text DEFAULT 'main' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_employees_branch` ON `employees` (`branch`);--> statement-breakpoint
ALTER TABLE `notifications` ADD `branch` text DEFAULT 'main' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_notifications_branch` ON `notifications` (`branch`);--> statement-breakpoint
ALTER TABLE `routines` ADD `branch` text DEFAULT 'main' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_routines_branch` ON `routines` (`branch`);--> statement-breakpoint
ALTER TABLE `tasks` ADD `branch` text DEFAULT 'main' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_tasks_branch_date` ON `tasks` (`branch`,`date`);--> statement-breakpoint
CREATE INDEX `idx_photos_task` ON `photos` (`task`);