import { env } from 'cloudflare:workers';
import { remind } from '@/lib/tasks';
export async function POST(req:Request){const key=(env as any).REMINDER_SECRET;if(!key||req.headers.get('authorization')!==`Bearer ${key}`)return Response.json({error:'ไม่ได้รับอนุญาต'},{status:401});try{const b:any=await req.json().catch(()=>({}));return Response.json(await remind(typeof b.branch==='string'?b.branch:'main'));}catch{return Response.json({error:'ส่งแจ้งเตือนไม่สำเร็จ'},{status:502});}}
