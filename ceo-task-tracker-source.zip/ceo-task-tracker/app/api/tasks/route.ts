import { db,bucket,today,validDate,materialize } from '@/lib/tasks';
import { branchAccess,checkOrigin,fail,json,AccessError } from '@/lib/access';
import { env } from 'cloudflare:workers';
export async function GET(req:Request){try{
const url=new URL(req.url);const {branch,canManage}=await branchAccess(req,url.searchParams.get('branch'));const id=branch.id;await materialize(id);const day=url.searchParams.get('date')||today();if(!validDate(day))throw new AccessError('วันที่ไม่ถูกต้อง',400);
const [employees,tasks,photos,routines,overdue,logs]=await Promise.all([
 db().prepare('SELECT * FROM employees WHERE branch=? ORDER BY name').bind(id).all(),
 db().prepare('SELECT t.*,e.name FROM tasks t JOIN employees e ON e.id=t.employee AND e.branch=t.branch WHERE t.branch=? AND date=? ORDER BY time,created').bind(id,day).all(),
 db().prepare('SELECT p.id,p.task FROM photos p JOIN tasks t ON t.id=p.task WHERE t.branch=? AND (t.date=? OR (t.status!=? AND t.date<?))').bind(id,day,'done',today()).all(),
 db().prepare('SELECT r.*,e.name FROM routines r JOIN employees e ON r.employee=e.id AND e.branch=r.branch WHERE r.branch=? ORDER BY active DESC,time').bind(id).all(),
 db().prepare("SELECT t.*,e.name FROM tasks t JOIN employees e ON e.id=t.employee AND e.branch=t.branch WHERE t.branch=? AND status!='done' AND date<? ORDER BY date,time").bind(id,today()).all(),
 canManage?db().prepare('SELECT * FROM notifications WHERE branch=? ORDER BY created DESC LIMIT 10').bind(id).all():Promise.resolve({results:[]})]);
return json({employees:employees.results,tasks:tasks.results,photos:photos.results,routines:routines.results,overdue:overdue.results,logs:logs.results,lineConfigured:id==='main'&&!!((env as any).LINE_CHANNEL_ACCESS_TOKEN&&(env as any).LINE_GROUP_ID),schedulerConfigured:id==='main'&&!!(env as any).REMINDER_SCHEDULE_ACTIVE,today:today(),branch,canManage});
}catch(e){return fail(e);}}
export async function POST(req:Request){try{
checkOrigin(req);const b:any=await req.json();const manageable=['employee','create','reopen','routineToggle'];const {branch}=await branchAccess(req,String(b.branch||''),manageable.includes(b.action));const branchId=branch.id,id=crypto.randomUUID();
if(b.action==='employee'){const name=String(b.name||'').trim();if(!name||name.length>80)throw new AccessError('กรุณาใส่ชื่อไม่เกิน 80 ตัวอักษร',400);await db().prepare('INSERT INTO employees(id,name,branch) VALUES (?,?,?)').bind(id,name,branchId).run();}
else if(b.action==='create'){
 const title=String(b.title||'').trim(),date=String(b.date||''),time=String(b.time||'');if(!title||title.length>200||!validDate(date)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw new AccessError('ตรวจสอบชื่องาน วันที่ และเวลาส่ง',400);
 const employee=await db().prepare('SELECT id FROM employees WHERE id=? AND branch=?').bind(b.employee,branchId).first();if(!employee)throw new AccessError('กรุณาเลือกพนักงานในร้านนี้',400);
 if(b.kind==='routine'){await db().prepare('INSERT INTO routines(id,title,employee,time,start,branch) VALUES (?,?,?,?,?,?)').bind(id,title,b.employee,time,date,branchId).run();await materialize(branchId);}
 else{await db().prepare('INSERT INTO tasks(id,title,employee,kind,priority,date,time,status,note,created,branch) VALUES (?,?,?,?,?,?,?,?,?,?,?)').bind(id,title,b.employee,'extra',b.priority==='urgent'?'urgent':'normal',date,time,'waiting','',new Date().toISOString(),branchId).run();}}
else if(b.action==='routineToggle'){
 const routine=await db().prepare('SELECT id FROM routines WHERE id=? AND branch=?').bind(b.id,branchId).first();if(!routine)throw new AccessError('ไม่พบงานประจำในร้านนี้',404);
 if(b.active){await db().prepare('UPDATE routines SET active=1,start=? WHERE id=? AND branch=?').bind(today(),b.id,branchId).run();}else{await materialize(branchId);await db().prepare('UPDATE routines SET active=0 WHERE id=? AND branch=?').bind(b.id,branchId).run();}}
else if(['start','reopen','submit'].includes(b.action)){
 const t=await db().prepare('SELECT * FROM tasks WHERE id=? AND branch=?').bind(b.id,branchId).first<any>();if(!t)throw new AccessError('ไม่พบงานในร้านนี้',404);
 if(b.action==='start'){await db().prepare("UPDATE tasks SET status='progress' WHERE id=? AND branch=? AND status='waiting'").bind(b.id,branchId).run();}
 else if(b.action==='reopen'){await db().prepare("UPDATE tasks SET status='waiting',completed=NULL WHERE id=? AND branch=?").bind(b.id,branchId).run();}
 else{
 if(t.status==='done')throw new AccessError('งานนี้ส่งเสร็จแล้ว กรุณารีเฟรชหน้า',409);
 if(!Array.isArray(b.photos)||b.photos.length<1||b.photos.length>3)throw new AccessError('กรุณาแนบรูป 1–3 รูป',400);
 const keys:{id:string;key:string;type:string}[]=[];
 try{for(const p of b.photos){if(typeof p!=='string'||p.length>7500000||!/^data:image\/(jpeg|png|webp);base64,/.test(p))throw new AccessError('รองรับรูป JPG, PNG, WebP ไม่เกิน 5 MB ต่อรูป',400);const [prefix,encoded]=p.split(',');const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));if(bytes.length>5*1024*1024)throw new AccessError('รูปใหญ่เกิน 5 MB',400);const type=prefix.split(':')[1].split(';')[0],photoId=crypto.randomUUID(),key='evidence/'+branchId+'/'+photoId;await bucket().put(key,bytes,{httpMetadata:{contentType:type}});keys.push({id:photoId,key,type});}
 const stmts=keys.map(p=>db().prepare('INSERT INTO photos(id,task,key,type) SELECT ?,id,?,? FROM tasks WHERE id=? AND branch=?').bind(p.id,p.key,p.type,b.id,branchId));stmts.push(db().prepare("UPDATE tasks SET status='done',completed=?,note=? WHERE id=? AND branch=?").bind(new Date().toISOString(),String(b.note||'').slice(0,2000),b.id,branchId));await db().batch(stmts);
 }catch(error){await Promise.all(keys.map(p=>bucket().delete(p.key)));throw error;}
 }}else throw new AccessError('ไม่พบคำสั่ง',400);return json({ok:true,id});
}catch(e){return fail(e);}}
