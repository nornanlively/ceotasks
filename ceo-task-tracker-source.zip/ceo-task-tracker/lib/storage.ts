import { env } from 'cloudflare:workers';
export function db(){if(!env.DB)throw new Error('ไม่สามารถเชื่อมต่อข้อมูล กรุณาลองใหม่');return env.DB;}
export function bucket(){if(!env.BUCKET)throw new Error('ไม่สามารถเชื่อมต่อพื้นที่เก็บรูป');return env.BUCKET;}
