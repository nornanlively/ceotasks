import { env } from 'cloudflare:workers';
import { db } from './storage';
export class AccessError extends Error{constructor(message:string,public status:number){super(message);}}
export function fail(error:unknown){if(error instanceof AccessError)return Response.json({error:error.message},{status:error.status,headers:{'Cache-Control':'no-store'}});console.error(error);return Response.json({error:'ดำเนินการไม่สำเร็จ กรุณาลองใหม่'},{status:500,headers:{'Cache-Control':'no-store'}});}
export function json(value:unknown,status=200){return Response.json(value,{status,headers:{'Cache-Control':'no-store'}});}
export function checkOrigin(req:Request){const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)throw new AccessError('คำขอไม่ถูกต้อง',403);}
export type Identity={email:string;user_id:string;owner:number};
async function bootstrap(){
 const marker=await db().prepare("SELECT value FROM app_settings WHERE key='branch_setup_v1'").first();if(marker)return;
 const emails=String((env as any).LEGACY_BRANCH_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
 const stmts=[db().prepare("INSERT OR IGNORE INTO branches(id,name,created) VALUES ('main','CEO เกษตร',?)").bind(new Date().toISOString()),...emails.map(email=>db().prepare("INSERT OR IGNORE INTO memberships(branch,email,role) SELECT 'main',?,'manager' WHERE NOT EXISTS (SELECT 1 FROM app_settings WHERE key='branch_setup_v1')").bind(email)),db().prepare("INSERT OR IGNORE INTO app_settings(key,value) VALUES ('branch_setup_v1','done')")];
 await db().batch(stmts);
}
export async function identity(req:Request):Promise<Identity>{
 const uid=req.headers.get('oai-authenticated-user-id'),email=req.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();
 if(!uid||!email)throw new AccessError('กรุณาเข้าสู่ระบบก่อนใช้งาน',401);
 await bootstrap();
 let record=await db().prepare('SELECT * FROM identities WHERE user_id=?').bind(uid).first<Identity>();if(record)return record;
 const ownerEmail=String((env as any).OWNER_EMAIL||'').trim().toLowerCase();
 const invited=await db().prepare('SELECT 1 FROM memberships WHERE email=? LIMIT 1').bind(email).first();
 if(email!==ownerEmail&&!invited)throw new AccessError('บัญชีนี้ยังไม่ได้ผูกกับร้าน กรุณาให้เจ้าของร้านเพิ่มสิทธิ์',403);
 await db().prepare('INSERT OR IGNORE INTO identities(email,user_id,owner) VALUES (?,?,?)').bind(email,uid,email===ownerEmail?1:0).run();
 record=await db().prepare('SELECT * FROM identities WHERE user_id=?').bind(uid).first<Identity>();
 if(!record)throw new AccessError('บัญชีนี้ผูกกับผู้ใช้เดิมแล้ว กรุณาติดต่อเจ้าของร้าน',403);return record;
}
export async function branchAccess(req:Request,branchId:string|null,manager=false){
 const user=await identity(req);if(!branchId)throw new AccessError('กรุณาเลือกร้านก่อน',400);
 const branch=await db().prepare('SELECT * FROM branches WHERE id=?').bind(branchId).first<{id:string;name:string;created:string}>();
 if(!branch)throw new AccessError('ไม่พบร้านหรือไม่มีสิทธิ์เข้าถึง',403);
 let role=user.owner?'owner':'';if(!role){const m=await db().prepare('SELECT role FROM memberships WHERE branch=? AND email=?').bind(branchId,user.email).first<{role:string}>();role=m?.role||'';}
 if(!role||(manager&&role==='staff'))throw new AccessError('บัญชีนี้ไม่มีสิทธิ์ดำเนินการในร้านนี้',403);
 return {user,branch,role,canManage:role!=='staff'};
}
export async function ownerAccess(req:Request){const u=await identity(req);if(!u.owner)throw new AccessError('เฉพาะเจ้าของระบบเท่านั้น',403);return u;}
