import { env } from 'cloudflare:workers';
import { db } from './storage';
export { db,bucket } from './storage';
export function today(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
export function validDate(v:string){return /^\d{4}-\d{2}-\d{2}$/.test(v)&&!isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;}
export async function materialize(branch:string){await db().prepare(`WITH RECURSIVE days(rid,title,employee,time,d,branch) AS (SELECT id,title,employee,time,start,branch FROM routines WHERE branch=? AND active=1 AND start<=? UNION ALL SELECT rid,title,employee,time,date(d,'+1 day'),branch FROM days WHERE d<?) INSERT OR IGNORE INTO tasks (id,title,employee,kind,priority,date,time,status,routine,note,created,branch) SELECT rid||':'||d,title,employee,'routine','normal',d,time,'waiting',rid,'',?,branch FROM days`).bind(branch,today(),today(),new Date().toISOString()).run();}
export async function remind(branch='main'){
 // Legacy LINE credentials belong exclusively to the existing main branch.
 const config=env as any;if(branch!=='main'||!config.LINE_CHANNEL_ACCESS_TOKEN||!config.LINE_GROUP_ID)return {sent:false,reason:'ร้านนี้ยังไม่ได้เชื่อม LINE'};
 await materialize(branch);const now=new Date().toISOString();const rows=await db().prepare(`SELECT t.*,e.name FROM tasks t JOIN employees e ON e.id=t.employee AND e.branch=t.branch WHERE t.branch=? AND t.kind='routine' AND t.status!='done' AND (t.date||'T'||t.time||':00+07:00')<=? ORDER BY t.date,t.time`).bind(branch,new Date(Date.now()+7*3600000).toISOString().slice(0,19)+'+07:00').all<any>();
 if(!rows.results.length)return {sent:false,reason:'ไม่มีงานประจำเกินกำหนด'};
 const id='daily:'+branch+':'+today();const claim=await db().prepare('INSERT OR IGNORE INTO notifications(id,status,created,detail,branch) VALUES (?,?,?,?,?)').bind(id,'sending',now,'',branch).run();if(!claim.meta.changes)return {sent:false,reason:'รายการเตือนวันนี้ถูกดำเนินการแล้ว'};
 const store=await db().prepare('SELECT name FROM branches WHERE id=?').bind(branch).first<{name:string}>();
 const text=`🔔 ${store?.name||'ร้าน'} · เตือนส่งงานประจำ\n`+rows.results.slice(0,40).map((t:any)=>`${t.name}: ${t.title} (${t.date} ${t.time}) ยังไม่ส่งงาน`).join('\n')+`\nรวม ${rows.results.length} งาน กรุณาส่งรูปหลักฐานในระบบ`;
 try{const r=await fetch('https://api.line.me/v2/bot/message/push',{method:'POST',headers:{Authorization:`Bearer ${config.LINE_CHANNEL_ACCESS_TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify({to:config.LINE_GROUP_ID,messages:[{type:'text',text:text.slice(0,4900)}]})});if(!r.ok)throw new Error(`LINE ตอบกลับ ${r.status}`);await db().prepare('UPDATE notifications SET status=?,detail=? WHERE id=? AND branch=?').bind('sent',`${rows.results.length} งาน`,id,branch).run();return {sent:true,count:rows.results.length};}catch(e){await db().prepare('UPDATE notifications SET status=?,detail=? WHERE id=? AND branch=?').bind('failed',String(e),id,branch).run();throw e;}
}
