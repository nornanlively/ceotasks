# CEO เกษตร · ติดตามงาน

Private team task tracker. D1 stores employees, recurring definitions, task instances, evidence metadata and notification history. R2 stores image bytes. All task deadlines use Asia/Bangkok. Empty initial database; no seeded employee data.

## Workflow
Create employees, assign a daily routine or one-off urgent/normal task, start work, submit 1–3 images and optional note. A successful image write and database batch marks the task done. Completion timestamp is retained. Owner can request resubmission while retaining evidence history. Daily templates materialize idempotent per-date task IDs on access and in the reminder writer; historical overdue tasks remain visible. Pausing a template stops new creation, never deletes prior tasks.

## LINE integration: prerequisite pending
The app intentionally reports LINE and scheduling as unconfigured. No reminder schedule has been created. Required secrets: LINE_CHANNEL_ACCESS_TOKEN, LINE_GROUP_ID (correct employee group), REMINDER_SECRET. Runtime values must be installed through Sites environment settings, never committed or put into client bundles. Verify group identity with the owner before a first real send. The bot must be invited into that group and have Messaging API group participation enabled.

POST /api/remind is a secret-authenticated writer for future unattended execution. It materializes missing daily tasks, sends a daily summary of overdue incomplete routines, and records sent/failed history. It limits claims to once per Bangkok day. Failed claims need explicit operator review, avoiding uncertain duplicate sends. The platform private-site ingress still applies; do not assume an external caller can reach this route. Establish supported Site service access and verify the unattended writer before creating a Sites schedule. Set REMINDER_SCHEDULE_ACTIVE only after a real schedule exists and has been verified. Never claim that browser refresh is a reminder schedule.

## Branch accounts and access

The existing Site audience is preserved, including its external viewer. Browser login uses dispatch-owned ChatGPT authentication; the app does not issue shared branch passwords. OWNER_EMAIL bootstraps exactly the configured owner. Verified identity is then pinned to the stable Site-specific user ID in D1; an email collision with another user ID fails closed.

All previous employee, task, routine and notification rows gain branch=main using an append-only schema migration. Runtime initialization creates the existing main branch once, and imports only explicitly configured LEGACY_BRANCH_EMAILS as main-branch managers. It is idempotent and does not re-add revoked memberships. New branches start empty. Names are freely editable and need not share a brand.

Owners create/rename branches and assign member emails and manager/staff roles. A staff account can read and submit tasks within its authorized branch. Managers can also manage employees, assign tasks and request resubmission. Owners can access every branch. A user with only one branch automatically enters it; other users choose among only their allowed branches. Logout is a top-level link to the dispatch-owned signout route.

Every task read/write, employee assignment, routine change, image retrieval and notification log is scoped and authorized server-side. Photos inherit scope from their task. Private image responses use no-store. Legacy LINE configuration belongs exclusively to main and never sends another branch's data to that group. LINE setup remains pending; no automation was enabled by this update.

Two gates apply to a new external account: Sites viewer permission and D1 branch membership. The owner interface explains this explicitly. App membership changes do not send invitations or change the Site audience. Manage Site external viewers through the supported access tool; do not change to public to work around an access failure.

## Verification

`node scripts/test-branch-isolation.mjs` uses in-memory SQLite and isolated mock R2, with the real compiled API handlers. It verifies migration preservation, stable owner identity, branch membership filtering, forbidden cross-branch writes and photos, staff/manager permissions, routine idempotency, access revocation and notification isolation. No production test records are created.
